<?php
function users_check_duplicate($e){
    if (property_exists($e, 'errorInfo') && is_array($e->errorInfo) && count($e->errorInfo) >= 2) {
        if ($e->errorInfo[1] === 1062) {
            preg_match("/Users.(\w+)/", $e->errorInfo[2], $matches);
            if (isset($matches[1])) {
                flash("The chosen " . $matches[1] . " is not available.", "warning");
            } else {
                flash("An unhandled error occurred", "danger");
                error_log(var_export($e->errorInfo, true));
            }
        } else {
            flash("An unhandled error occurred", "danger");
            error_log(var_export($e->errorInfo, true));
        }
    } else {
        flash("An unhandled error occurred", "danger");
        error_log("Unexpected exception: " . $e->getMessage());
    }
}
?>
