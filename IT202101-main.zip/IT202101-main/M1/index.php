<?php
require(__DIR__ . "/../../lib/functions.php");
die(header("Location: $BASE_PATH/login.php"));