-- Active: 1694902824116@@db.ethereallab.app@3306@ms2969
ALTER TABLE Users
ADD COLUMN user_roles VARCHAR(30) NOT NULL DEFAULT 'User';
