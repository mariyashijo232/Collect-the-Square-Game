<table><tr><td> <em>Assignment: </em> IT202 Milestone1 Deliverable</td></tr>
<tr><td> <em>Student: </em> Mariya Shijo (ms2969)</td></tr>
<tr><td> <em>Generated: </em> 12/16/2023 12:59:32 PM</td></tr>
<tr><td> <em>Grading Link: </em> <a rel="noreferrer noopener" href="https://learn.ethereallab.app/homework/IT202-101-F23/it202-milestone1-deliverable/grade/ms2969" target="_blank">Grading</a></td></tr></table>
<table><tr><td> <em>Instructions: </em> <ol><li>Checkout Milestone1 branch</li><li>Create a milestone1.md file in your Project folder</li><li>Git add/commit/push this empty file to Milestone1 (you'll need the link later)</li><li>Fill in the deliverable items<ol><li>For each feature, add a direct link (or links) to the expected file the implements the feature from Heroku Prod (I.e,&nbsp;<a href="https://mt85-prod.herokuapp.com/Project/register.php">https://mt85-prod.herokuapp.com/Project/register.php</a>)</li></ol></li><li>Ensure your images display correctly in the sample markdown at the bottom</li><ol><li>NOTE: You may want to try to capture as much checklist evidence in your screenshots as possible, you do not need individual screenshots and are recommended to combine things when possible. Also, some screenshots may be reused if applicable.</li></ol><li>Save the submission items</li><li>Copy/paste the markdown from the "Copy markdown to clipboard link" or via the download button</li><li>Paste the code into the milestone1.md file or overwrite the file</li><li>Git add/commit/push the md file to Milestone1</li><li>Double check the images load when viewing the markdown file (points will be lost for invalid/non-loading images)</li><li>Make a pull request from Milestone1 to dev and merge it (resolve any conflicts)<ol><li>Make sure everything looks ok on heroku dev</li></ol></li><li>Make a pull request from dev to prod (resolve any conflicts)<ol><li>Make sure everything looks ok on heroku prod</li></ol></li><li>Submit the direct link from github prod branch to the milestone1.md file (no other links will be accepted and will result in 0)</li></ol></td></tr></table>
<table><tr><td> <em>Deliverable 1: </em> Feature: User will be able to register a new account </td></tr><tr><td><em>Status: </em> <img width="100" height="20" src="https://user-images.githubusercontent.com/54863474/211707773-e6aef7cb-d5b2-4053-bbb1-b09fc609041e.png"></td></tr>
<tr><td><table><tr><td> <em>Sub-Task 1: </em> Add one or more screenshots of the application showing the form and validation errors per the feature requirements</td></tr>
<tr><td><table><tr><td><img width="768px" src="https://firebasestorage.googleapis.com/v0/b/learn-e1de9.appspot.com/o/assignments%2Fms2969%2F2023-12-04T21.12.26Screenshot%202023-12-04%20161126.png.webp?alt=media&token=2aa97505-fe53-4f16-ab37-a25420aeec44"/></td></tr>
<tr><td> <em>Caption:</em> <p>Passwords do not match<br></p>
</td></tr>
<tr><td><img width="768px" src="https://firebasestorage.googleapis.com/v0/b/learn-e1de9.appspot.com/o/assignments%2Fms2969%2F2023-12-04T21.14.47Screenshot%202023-12-04%20161413.png.webp?alt=media&token=b4190e41-eb50-403c-81cd-a8e9a7ca2220"/></td></tr>
<tr><td> <em>Caption:</em> <p>Not correct format for email<br></p>
</td></tr>
<tr><td><img width="768px" src="https://firebasestorage.googleapis.com/v0/b/learn-e1de9.appspot.com/o/assignments%2Fms2969%2F2023-12-04T21.16.35Screenshot%202023-12-04%20161624.png.webp?alt=media&token=112bd44e-fa30-419a-8e2a-608af3ba5a53"/></td></tr>
<tr><td> <em>Caption:</em> <p>Does not fill requirements for password<br></p>
</td></tr>
<tr><td><img width="768px" src="https://firebasestorage.googleapis.com/v0/b/learn-e1de9.appspot.com/o/assignments%2Fms2969%2F2023-12-15T23.49.56Screenshot%202023-12-15%20184913.png.webp?alt=media&token=f5ae4564-cd9d-4cbf-a8a1-25169fc7be69"/></td></tr>
<tr><td> <em>Caption:</em> <p>username taken <br></p>
</td></tr>
<tr><td><img width="768px" src="https://firebasestorage.googleapis.com/v0/b/learn-e1de9.appspot.com/o/assignments%2Fms2969%2F2023-12-15T23.52.05Screenshot%202023-12-15%20185149.png.webp?alt=media&token=01f97365-dc95-40dd-a918-c38655354bd8"/></td></tr>
<tr><td> <em>Caption:</em> <p>Email has already been registered. <br></p>
</td></tr>
<tr><td><img width="768px" src="https://firebasestorage.googleapis.com/v0/b/learn-e1de9.appspot.com/o/assignments%2Fms2969%2F2023-12-15T23.53.31Screenshot%202023-12-15%20185317.png.webp?alt=media&token=bbb7429d-3f2b-43a8-b33f-4b4e78233fc2"/></td></tr>
<tr><td> <em>Caption:</em> <p>data being submitted.<br></p>
</td></tr>
</table></td></tr>
<tr><td> <em>Sub-Task 2: </em> Add a screenshot of the Users table with data in it</td></tr>
<tr><td><table><tr><td><img width="768px" src="https://firebasestorage.googleapis.com/v0/b/learn-e1de9.appspot.com/o/assignments%2Fms2969%2F2023-12-15T23.54.53Screenshot%202023-12-15%20185445.png.webp?alt=media&token=70d57ef0-943c-49a3-b371-114c667ecef1"/></td></tr>
<tr><td> <em>Caption:</em> <p>user data in the database<br></p>
</td></tr>
</table></td></tr>
<tr><td> <em>Sub-Task 3: </em> Add the related pull request(s) for this feature</td></tr>
<tr><td> <a rel="noreferrer noopener" target="_blank" href="https://github.com/mariyashijo232/IT202101/pull/26">https://github.com/mariyashijo232/IT202101/pull/26</a> </td></tr>
<tr><td> <em>Sub-Task 4: </em> Explain briefly how the process/code works</td></tr>
<tr><td> <em>Response:</em> <p>When you join, you share your email, pick a username, and create a<br>secret password. The website checks if you did it right. Your password is<br>turned into a secret code that only the computer can understand. Everything is<br>saved in a digital storage called a database. Later, when you log in,<br>the website checks for your details.&nbsp;Validation makes sure the info you give is<br>good. On the form (front), it checks if email and username are not<br>empty, email looks right, password is not short, and both passwords match and<br>then backend, rechecks these things, plus if email is unique. If not, it<br>gives out an alert. It also checks if the email is already registered<br>or if the username in taken.&nbsp;<div><br></div><div><br></div><br></p><br></td></tr>
</table></td></tr>
<table><tr><td> <em>Deliverable 2: </em> Feature: User will be able to login to their account </td></tr><tr><td><em>Status: </em> <img width="100" height="20" src="https://user-images.githubusercontent.com/54863474/211707773-e6aef7cb-d5b2-4053-bbb1-b09fc609041e.png"></td></tr>
<tr><td><table><tr><td> <em>Sub-Task 1: </em> Add one or more screenshots of the application showing the form and validation errors per the feature requirements</td></tr>
<tr><td><table><tr><td><img width="768px" src="https://firebasestorage.googleapis.com/v0/b/learn-e1de9.appspot.com/o/assignments%2Fms2969%2F2023-12-15T23.56.23Screenshot%202023-12-15%20185618.png.webp?alt=media&token=4aa32f6d-66cd-488c-9f14-874693e58724"/></td></tr>
<tr><td> <em>Caption:</em> <p>Wrong password<br></p>
</td></tr>
<tr><td><img width="768px" src="https://firebasestorage.googleapis.com/v0/b/learn-e1de9.appspot.com/o/assignments%2Fms2969%2F2023-12-15T23.57.14Screenshot%202023-12-15%20185700.png.webp?alt=media&token=04e60707-5b6d-435e-95a8-9ac67d600737"/></td></tr>
<tr><td> <em>Caption:</em> <p>email not found in the database.<br></p>
</td></tr>
</table></td></tr>
<tr><td> <em>Sub-Task 2: </em> Add a screenshot of successful login</td></tr>
<tr><td><table><tr><td><img width="768px" src="https://firebasestorage.googleapis.com/v0/b/learn-e1de9.appspot.com/o/assignments%2Fms2969%2F2023-12-15T23.59.13Screenshot%202023-12-15%20185905.png.webp?alt=media&token=5f64a524-1034-4b1d-884d-cd74e243c818"/></td></tr>
<tr><td> <em>Caption:</em> <p>successful login<br></p>
</td></tr>
</table></td></tr>
<tr><td> <em>Sub-Task 3: </em> Add the related pull request(s) for this feature</td></tr>
<tr><td> <a rel="noreferrer noopener" target="_blank" href="https://github.com/mariyashijo232/IT202101/pull/26">https://github.com/mariyashijo232/IT202101/pull/26</a> </td></tr>
<tr><td> <em>Sub-Task 4: </em> Explain briefly how the process/code works</td></tr>
<tr><td> <em>Response:</em> <p>The login page processes user input through both frontend and backend validation. JavaScript<br>is intended for client-side validation and on the server side, PHP ensures that<br>required fields are present, performs email and password checks, and checks the database<br>to prevent duplicate registrations. Passwords are also hashed before being stored.<br></p><br></td></tr>
</table></td></tr>
<table><tr><td> <em>Deliverable 3: </em> Feat: Users will be able to logout </td></tr><tr><td><em>Status: </em> <img width="100" height="20" src="https://user-images.githubusercontent.com/54863474/211707773-e6aef7cb-d5b2-4053-bbb1-b09fc609041e.png"></td></tr>
<tr><td><table><tr><td> <em>Sub-Task 1: </em> Add a screenshot showing the successful logout message</td></tr>
<tr><td><table><tr><td><img width="768px" src="https://firebasestorage.googleapis.com/v0/b/learn-e1de9.appspot.com/o/assignments%2Fms2969%2F2023-12-16T00.02.48Screenshot%202023-12-15%20190240.png.webp?alt=media&token=ee88a852-aec6-43cf-b4fd-daffd91d6c97"/></td></tr>
<tr><td> <em>Caption:</em> <p>This is the logout page. <br></p>
</td></tr>
</table></td></tr>
<tr><td> <em>Sub-Task 2: </em> Add a screenshot showing the logged out user can't access a login-protected page</td></tr>
<tr><td><table><tr><td><img width="768px" src="https://firebasestorage.googleapis.com/v0/b/learn-e1de9.appspot.com/o/assignments%2Fms2969%2F2023-12-16T00.21.46Screenshot%202023-12-15%20192134.png.webp?alt=media&token=256876b8-352b-4eac-86cd-1eaeab13da9e"/></td></tr>
<tr><td> <em>Caption:</em> <p>error message<br></p>
</td></tr>
<tr><td><img width="768px" src="https://firebasestorage.googleapis.com/v0/b/learn-e1de9.appspot.com/o/assignments%2Fms2969%2F2023-12-16T00.22.18Screenshot%202023-12-15%20192207.png.webp?alt=media&token=c4c01b1e-966f-4fc8-9398-748a2f340e72"/></td></tr>
<tr><td> <em>Caption:</em> <p>You can see that I tried to implement a pop up that says<br>&quot;please login to see the page&quot; but I doesn&#39;t work.<br></p>
</td></tr>
</table></td></tr>
<tr><td> <em>Sub-Task 3: </em> Add the related pull request(s) for this feature</td></tr>
<tr><td> <a rel="noreferrer noopener" target="_blank" href="https://github.com/mariyashijo232/IT202101/pull/26">https://github.com/mariyashijo232/IT202101/pull/26</a> </td></tr>
<tr><td> <em>Sub-Task 4: </em> Explain briefly how the process/code works</td></tr>
<tr><td> <em>Response:</em> <p>You can see that I tried to implement a pop up that says<br>&quot;please login to see the page&quot; but I doesn&#39;t work. This was the<br>code I used:&nbsp;<span style="background-color: rgb(31, 31, 31); font-family: Consolas, &quot;Courier New&quot;, monospace; white-space:<br>pre; color: rgb(197, 134, 192);">if</span><span style="background-color: rgb(31, 31, 31); font-family: Consolas, &quot;Courier New&quot;,<br>monospace; white-space: pre; color: rgb(212, 212, 212);"> (!</span><span style="background-color: rgb(31, 31, 31); font-family:<br>Consolas, &quot;Courier New&quot;, monospace; white-space: pre; color: rgb(220, 220, 170);">is_logged_in</span><span style="background-color: rgb(31, 31,<br>31); font-family: Consolas, &quot;Courier New&quot;, monospace; white-space: pre; color: rgb(212, 212, 212);">()) {</span>&lt;div<br>style=&quot;color: rgb(204, 204, 204); background-color: rgb(31, 31, 31); font-family: Consolas, &quot;Courier New&quot;, monospace;<br>line-height: 19px; white-space: pre;&quot;&gt;<div><span style="color: #d4d4d4;">&nbsp; &nbsp; </span><span style="color: #dcdcaa;">flash</span><span style="color: #d4d4d4;">(</span><span style="color:<br>#ce9178;">&quot;Please login to access this page.&quot;</span><span style="color: #d4d4d4;">, </span><span style="color: #ce9178;">&quot;info&quot;</span><span style="color: #d4d4d4;">);</span></div><div>&lt;span<br>style=&quot;color: #d4d4d4;&quot;&gt;&nbsp; &nbsp; </span><span style="color: #c586c0;">die</span><span style="color: #d4d4d4;">(</span><span style="color: #dcdcaa;">header</span><span style="color: #d4d4d4;">(</span><span style="color:<br>#ce9178;">&quot;Location: login.php&quot;</span><span style="color: #d4d4d4;">));</span></div><div><span style="color: #d4d4d4;">}. But for some reason I kept getting<br>an error. </span></div></div><br></p><br></td></tr>
</table></td></tr>
<table><tr><td> <em>Deliverable 4: </em> Feature: Basic Security Rules Implemented / Basic Roles Implemented </td></tr><tr><td><em>Status: </em> <img width="100" height="20" src="https://user-images.githubusercontent.com/54863474/211707834-bf5a5b13-ec36-4597-9741-aa830c195be2.png"></td></tr>
<tr><td><table><tr><td> <em>Sub-Task 1: </em> Add a screenshot showing the logged out user can't access a login-protected page (may be the same as similar request)</td></tr>
<tr><td><table><tr><td>Missing Image</td></tr>
<tr><td> <em>Caption:</em> (missing)</td></tr>
</table></td></tr>
<tr><td> <em>Sub-Task 2: </em> Add a screenshot showing a user without an appropriate role can't access the role-protected page</td></tr>
<tr><td><table><tr><td><img width="768px" src="https://firebasestorage.googleapis.com/v0/b/learn-e1de9.appspot.com/o/assignments%2Fms2969%2F2023-12-16T17.55.54Screenshot%202023-12-16%20125525.png.webp?alt=media&token=b9972537-4b7a-4f53-91cf-fd36600e37c3"/></td></tr>
<tr><td> <em>Caption:</em> <p>The code that I used. But it doesn&#39;t work. <br></p>
</td></tr>
</table></td></tr>
<tr><td> <em>Sub-Task 3: </em> Add a screenshot of the Roles table with valid data</td></tr>
<tr><td><table><tr><td>Missing Image</td></tr>
<tr><td> <em>Caption:</em> (missing)</td></tr>
</table></td></tr>
<tr><td> <em>Sub-Task 4: </em> Add a screenshot of the UserRoles table with valid data</td></tr>
<tr><td><table><tr><td><img width="768px" src="https://firebasestorage.googleapis.com/v0/b/learn-e1de9.appspot.com/o/assignments%2Fms2969%2F2023-12-16T01.34.52Screenshot%202023-12-15%20203447.png.webp?alt=media&token=55cf3807-31c2-4bfd-907c-70fe37eda89a"/></td></tr>
<tr><td> <em>Caption:</em> <p>users tables<br></p>
</td></tr>
</table></td></tr>
<tr><td> <em>Sub-Task 5: </em> Add the related pull request(s) for these features</td></tr>
<tr><td> <a rel="noreferrer noopener" target="_blank" href="https://github.com/mariyashijo232/IT202101/pull/26">https://github.com/mariyashijo232/IT202101/pull/26</a> </td></tr>
<tr><td> <em>Sub-Task 6: </em> Explain briefly how the process/code works for login-protected pages</td></tr>
<tr><td> <em>Response:</em> <p>I wasn&#39;t able to do this. I tried to make pages login protected,<br>but the code just wasnt working.<br></p><br></td></tr>
<tr><td> <em>Sub-Task 7: </em> Explain briefly how the process/code works for role-protected pages</td></tr>
<tr><td> <em>Response:</em> <p>I wasn&#39;t able to do this. I tried to make pages login protected,<br>but the code just wasnt working.<br></p><br></td></tr>
</table></td></tr>
<table><tr><td> <em>Deliverable 5: </em> Feature: Site should have basic styles/theme applied; everything should be styled </td></tr><tr><td><em>Status: </em> <img width="100" height="20" src="https://user-images.githubusercontent.com/54863474/211707834-bf5a5b13-ec36-4597-9741-aa830c195be2.png"></td></tr>
<tr><td><table><tr><td> <em>Sub-Task 1: </em> Add screenshots to show examples of your site's styles/theme</td></tr>
<tr><td><table><tr><td><img width="768px" src="https://firebasestorage.googleapis.com/v0/b/learn-e1de9.appspot.com/o/assignments%2Fms2969%2F2023-12-16T17.30.21Screenshot%202023-12-16%20123008.png.webp?alt=media&token=7496c1e2-1553-4791-8d5a-68378f63631a"/></td></tr>
<tr><td> <em>Caption:</em> <p>My css file is not working. I tried to edit it but nothing<br>changes on my end<br></p>
</td></tr>
<tr><td><img width="768px" src="https://firebasestorage.googleapis.com/v0/b/learn-e1de9.appspot.com/o/assignments%2Fms2969%2F2023-12-16T17.30.50Screenshot%202023-12-16%20123043.png.webp?alt=media&token=8befd51a-12e1-4d06-a10d-e7c895814d8a"/></td></tr>
<tr><td> <em>Caption:</em> <p>here is what my homepage looks like. <br></p>
</td></tr>
</table></td></tr>
<tr><td> <em>Sub-Task 2: </em> Add the related pull request(s) for this feature</td></tr>
<tr><td> <a rel="noreferrer noopener" target="_blank" href="https://github.com/mariyashijo232/IT202101/pull/26">https://github.com/mariyashijo232/IT202101/pull/26</a> </td></tr>
<tr><td> <em>Sub-Task 3: </em> Briefly explain your CSS at a high level</td></tr>
<tr><td> <em>Response:</em> <p>(missing)</p><br></td></tr>
</table></td></tr>
<table><tr><td> <em>Deliverable 6: </em> Feature: Any output messages/errors should be "user friendly" </td></tr><tr><td><em>Status: </em> <img width="100" height="20" src="https://user-images.githubusercontent.com/54863474/211707773-e6aef7cb-d5b2-4053-bbb1-b09fc609041e.png"></td></tr>
<tr><td><table><tr><td> <em>Sub-Task 1: </em> Add screenshots of some examples of errors/messages</td></tr>
<tr><td><table><tr><td><img width="768px" src="https://firebasestorage.googleapis.com/v0/b/learn-e1de9.appspot.com/o/assignments%2Fms2969%2F2023-12-16T17.34.01Screenshot%202023-12-16%20123313.png.webp?alt=media&token=f5ac1165-00d9-407c-b702-2f422af30cc6"/></td></tr>
<tr><td> <em>Caption:</em> <p>wrong password alert<br></p>
</td></tr>
<tr><td><img width="768px" src="https://firebasestorage.googleapis.com/v0/b/learn-e1de9.appspot.com/o/assignments%2Fms2969%2F2023-12-16T17.34.04Screenshot%202023-12-16%20123332.png.webp?alt=media&token=4ccceaaf-4a3e-4461-954f-0f6c1da031e2"/></td></tr>
<tr><td> <em>Caption:</em> <p>email not found alert<br></p>
</td></tr>
<tr><td><img width="768px" src="https://firebasestorage.googleapis.com/v0/b/learn-e1de9.appspot.com/o/assignments%2Fms2969%2F2023-12-16T17.34.07Screenshot%202023-12-16%20123352.png.webp?alt=media&token=03cf29d9-f02f-4752-9b75-11c6530780a9"/></td></tr>
<tr><td> <em>Caption:</em> <p>please fill in field alert<br></p>
</td></tr>
</table></td></tr>
<tr><td> <em>Sub-Task 2: </em> Add a related pull request</td></tr>
<tr><td> <a rel="noreferrer noopener" target="_blank" href="https://github.com/mariyashijo232/IT202101/pull/26">https://github.com/mariyashijo232/IT202101/pull/26</a> </td></tr>
<tr><td> <em>Sub-Task 3: </em> Briefly explain how you made messages user friendly</td></tr>
<tr><td> <em>Response:</em> <p>In the provided code, client-side validation using JavaScript and server-side validation in PHP<br>have been implemented for a user login form. User-friendly messages, generated through the<br><code>flash</code> function, are displayed to inform users about any validation errors or authentication<br>issues during the login process.<br></p><br></td></tr>
</table></td></tr>
<table><tr><td> <em>Deliverable 7: </em> Feature: Users will be able to see their profile </td></tr><tr><td><em>Status: </em> <img width="100" height="20" src="https://user-images.githubusercontent.com/54863474/211707773-e6aef7cb-d5b2-4053-bbb1-b09fc609041e.png"></td></tr>
<tr><td><table><tr><td> <em>Sub-Task 1: </em> Add screenshots of the User Profile page</td></tr>
<tr><td><table><tr><td><img width="768px" src="https://firebasestorage.googleapis.com/v0/b/learn-e1de9.appspot.com/o/assignments%2Fms2969%2F2023-12-16T17.36.35Screenshot%202023-12-16%20123630.png.webp?alt=media&token=d87047e9-c395-4130-8c74-5f09974ed23e"/></td></tr>
<tr><td> <em>Caption:</em> <p>prefilled email and username<br></p>
</td></tr>
</table></td></tr>
<tr><td> <em>Sub-Task 2: </em> Add the related pull request(s) for this feature</td></tr>
<tr><td> <a rel="noreferrer noopener" target="_blank" href="https://github.com/mariyashijo232/IT202101/pull/26">https://github.com/mariyashijo232/IT202101/pull/26</a> </td></tr>
<tr><td> <em>Sub-Task 3: </em> Explain briefly how the process/code works (view only)</td></tr>
<tr><td> <em>Response:</em> <p>The code retrieves user data, such as email and username, from the users<br>database. This data is then automatically prefilled into the respective fields of a<br>form on the profile page.<br></p><br></td></tr>
</table></td></tr>
<table><tr><td> <em>Deliverable 8: </em> Feature: User will be able to edit their profile </td></tr><tr><td><em>Status: </em> <img width="100" height="20" src="https://user-images.githubusercontent.com/54863474/211707773-e6aef7cb-d5b2-4053-bbb1-b09fc609041e.png"></td></tr>
<tr><td><table><tr><td> <em>Sub-Task 1: </em> Add screenshots of the User Profile page validation messages and success messages</td></tr>
<tr><td><table><tr><td><img width="768px" src="https://firebasestorage.googleapis.com/v0/b/learn-e1de9.appspot.com/o/assignments%2Fms2969%2F2023-12-16T17.39.07Screenshot%202023-12-16%20123858.png.webp?alt=media&token=3e68b2b0-abae-42af-a8f1-d8563e4d3e8f"/></td></tr>
<tr><td> <em>Caption:</em> <p>email validation<br></p>
</td></tr>
<tr><td><img width="768px" src="https://firebasestorage.googleapis.com/v0/b/learn-e1de9.appspot.com/o/assignments%2Fms2969%2F2023-12-16T17.40.13Screenshot%202023-12-16%20124006.png.webp?alt=media&token=2064f723-12a9-458f-9920-d52c88a948a8"/></td></tr>
<tr><td> <em>Caption:</em> <p>username validation<br></p>
</td></tr>
<tr><td><img width="768px" src="https://firebasestorage.googleapis.com/v0/b/learn-e1de9.appspot.com/o/assignments%2Fms2969%2F2023-12-16T17.41.08Screenshot%202023-12-16%20124103.png.webp?alt=media&token=3a8dd651-15a7-4af8-b112-9d6e6be8e5ac"/></td></tr>
<tr><td> <em>Caption:</em> <p>password validation<br></p>
</td></tr>
<tr><td><img width="768px" src="https://firebasestorage.googleapis.com/v0/b/learn-e1de9.appspot.com/o/assignments%2Fms2969%2F2023-12-16T17.43.44Screenshot%202023-12-16%20124337.png.webp?alt=media&token=3aff052c-c0e7-4d8e-9f4d-961740454495"/></td></tr>
<tr><td> <em>Caption:</em> <p>password mismatch<br></p>
</td></tr>
<tr><td><img width="768px" src="https://firebasestorage.googleapis.com/v0/b/learn-e1de9.appspot.com/o/assignments%2Fms2969%2F2023-12-16T17.47.49Screenshot%202023-12-16%20124742.png.webp?alt=media&token=d883b02f-fe3b-432d-9a9b-fce9baaf1310"/></td></tr>
<tr><td> <em>Caption:</em> <p>email already taken<br></p>
</td></tr>
</table></td></tr>
<tr><td> <em>Sub-Task 2: </em> Add before and after screenshots of the Users table when a user edits their profile</td></tr>
<tr><td><table><tr><td><img width="768px" src="https://firebasestorage.googleapis.com/v0/b/learn-e1de9.appspot.com/o/assignments%2Fms2969%2F2023-12-16T17.50.03Screenshot%202023-12-16%20124954.png.webp?alt=media&token=c5ca4aa9-225e-47f5-8577-715b76fd50e0"/></td></tr>
<tr><td> <em>Caption:</em> <p>before the username is ms2969.<br></p>
</td></tr>
<tr><td><img width="768px" src="https://firebasestorage.googleapis.com/v0/b/learn-e1de9.appspot.com/o/assignments%2Fms2969%2F2023-12-16T17.50.58Screenshot%202023-12-16%20125051.png.webp?alt=media&token=2051d36a-7fb8-429d-b8d2-94ed17ca5f91"/></td></tr>
<tr><td> <em>Caption:</em> <p>after the username is ms1111<br></p>
</td></tr>
</table></td></tr>
<tr><td> <em>Sub-Task 3: </em> Add the related pull request(s) for this feature</td></tr>
<tr><td> <a rel="noreferrer noopener" target="_blank" href="https://github.com/mariyashijo232/IT202101/pull/26">https://github.com/mariyashijo232/IT202101/pull/26</a> </td></tr>
<tr><td> <em>Sub-Task 4: </em> Explain briefly how the process/code works (edit only)</td></tr>
<tr><td> <em>Response:</em> <p>The code makes sure you enter a valid email and username. If you<br>want to change your password, it checks if your current password is correct<br>and updates it. After you submit the form, it tells you if everything<br>went well or if there was a problem, like if the email is<br>already taken.<br></p><br></td></tr>
</table></td></tr>
<table><tr><td> <em>Deliverable 9: </em> Issues and Project Board </td></tr><tr><td><em>Status: </em> <img width="100" height="20" src="https://user-images.githubusercontent.com/54863474/211707773-e6aef7cb-d5b2-4053-bbb1-b09fc609041e.png"></td></tr>
<tr><td><table><tr><td> <em>Sub-Task 1: </em> Add screenshots showing which issues are done/closed (project board) Incomplete Issues should not be closed</td></tr>
<tr><td><table><tr><td><img width="768px" src="https://firebasestorage.googleapis.com/v0/b/learn-e1de9.appspot.com/o/assignments%2Fms2969%2F2023-12-16T17.53.05Screenshot%202023-12-16%20125252.png.webp?alt=media&token=7209ebfe-d511-40e5-9cfa-74079621f1fd"/></td></tr>
<tr><td> <em>Caption:</em> <p>My stles.css page isn&#39;t working<br></p>
</td></tr>
</table></td></tr>
<tr><td> <em>Sub-Task 2: </em> Include a direct link to your Project Board</td></tr>
<tr><td> <a rel="noreferrer noopener" target="_blank" href="https://github.com/mariyashijo232/IT202101/pull/26">https://github.com/mariyashijo232/IT202101/pull/26</a> </td></tr>
<tr><td> <em>Sub-Task 3: </em> Prod Application Link to Login Page</td></tr>
<tr><td> <a rel="noreferrer noopener" target="_blank" href="http://127.0.0.1/IT202101/M1/home.php">http://127.0.0.1/IT202101/M1/home.php</a> </td></tr>
</table></td></tr>
<table><tr><td><em>Grading Link: </em><a rel="noreferrer noopener" href="https://learn.ethereallab.app/homework/IT202-101-F23/it202-milestone1-deliverable/grade/ms2969" target="_blank">Grading</a></td></tr></table>