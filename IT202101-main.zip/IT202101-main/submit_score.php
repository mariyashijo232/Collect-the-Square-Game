<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

function getDB()
{
    global $db;
    if (!isset($db)) {
        try {
            require_once(__DIR__ . "/db.php"); 
        } catch (Exception $e) {
            echo var_export($e, true);
            error_log("getDB() error: " . var_export($e, true));
            $db = null;
        }
    }
    return $db;
}

$username = $_POST['username'];
$score = $_POST['score'];

$db = getDB();

if ($db) {
    $stmt = $db->prepare("INSERT INTO user_scores (username, score) VALUES (:username, :score)");
    $stmt->execute(array(":username" => $username, ":score" => $score));

    echo "Score submitted successfully";
} else {
    echo "Error: Unable to connect to the database.";
}
?>
